package com.first.androidcallsms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Prefix extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prefix);
    }

    public void onClickINT(View v){
        RadioGroup rg = findViewById(R.id.INTRG);
        int checked = rg.getCheckedRadioButtonId();
        RadioButton rb = findViewById(checked);
        // now that I have the radio button which is the clicked one when I click the button
        // can I intent a call to the INT Call activity
        Intent intent = new Intent(this, International.class);
        String prefix = rb.getText().toString();
        intent.putExtra("prefix", prefix);
        startActivity(intent);
    }
}