package com.first.androidcallsms;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;

public class SmsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sms_activity);
    }

    public void makeSMS (View v){
        EditText edn =(EditText)findViewById(R.id.TelNUMBER);
        EditText message = (EditText)findViewById(R.id.SmsContent);
        Intent intent = new Intent(Intent.ACTION_SENDTO);
        intent.setData(Uri.parse("smsto:"+edn.getText().toString()));  // This ensures only SMS apps respond
        intent.putExtra("sms_body", message.getText().toString());
        startActivity(intent);
    }
}