package com.first.countryinformationapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.RadioButton;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView iv = findViewById(R.id.IV);
        ScrollView sv = findViewById(R.id.SV);
        TextView tv = findViewById(R.id.TV);
        // to set default visualization
        if(((RadioButton)findViewById(R.id.EN)).isChecked()){
            iv.setImageResource(R.drawable.england);
            sv.setScrollY(0);
            tv.setText(R.string.en);
        }
    }

    public void onRadioButtonClicked(View view) {
        // Is the button now checked?
        boolean checked = ((RadioButton) view).isChecked();
        ImageView iv = findViewById(R.id.IV);
        ScrollView sv = findViewById(R.id.SV);
        TextView tv = findViewById(R.id.TV);
        // Check which radio button was clicked
        switch(view.getId()) {
            case R.id.EN:
                if (checked) {
                    // england case
                    iv.setImageResource(R.drawable.england);
                    sv.setScrollY(0);
                    tv.setText(getString(R.string.en));
                }
                break;
            case R.id.IT:
                if (checked) {
                    // england case
                    iv.setImageResource(R.drawable.italy);
                    sv.setScrollY(0);
                    tv.setText(R.string.it);
                }
                break;
            case R.id.FR:
                if (checked) {
                    // france case
                    iv.setImageResource(R.drawable.france);
                    sv.setScrollY(0);
                    tv.setText(R.string.fr);
                }
                break;
            case R.id.ES:
                if (checked) {
                    // spain case
                    iv.setImageResource(R.drawable.spain);
                    sv.setScrollY(0);
                    tv.setText(R.string.sp);
                }
                break;
        }
    }
}