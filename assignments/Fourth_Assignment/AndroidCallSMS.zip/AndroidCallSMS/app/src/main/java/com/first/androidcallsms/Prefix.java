package com.first.androidcallsms;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class Prefix extends AppCompatActivity {
    public static final String EXTRA_REPLY = "choosed prefix";
    private boolean choose;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prefix);
        Intent intent = getIntent();
        choose = intent.getBooleanExtra("choose", false);
    }

    public void onClickINT(View v){
        RadioGroup rg = findViewById(R.id.INTRG);
        int checked = rg.getCheckedRadioButtonId();
        RadioButton rb = findViewById(checked);
        String prefix = rb.getText().toString();
        // now that I have the radio button which is the clicked one when I click the button
        // can I intent a call to the INT Call activity
        if(choose){
            // Create an intent
            Intent replyIntent = new Intent();
            // Put the data to return into the extra
            replyIntent.putExtra(EXTRA_REPLY, prefix);
            // Set the activity's result to RESULT_OK
            setResult(RESULT_OK, replyIntent);
            // Finish the current activity
            finish();
        }else{
            Intent intent = new Intent(this, International.class);
            intent.putExtra("prefix", prefix);
            startActivity(intent);
            finish();
        }
    }

    public void OpenWiki(View v){
        Uri uri = Uri.parse("https://en.wikipedia.org/wiki/List_of_international_call_prefixes");
        Intent it = new Intent(Intent.ACTION_VIEW,uri);
        startActivity(it);
    }

}