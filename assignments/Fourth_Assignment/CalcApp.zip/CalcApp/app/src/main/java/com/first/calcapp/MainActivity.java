package com.first.calcapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    // Class name for Log tag.
    private static final String LOG_TAG = MainActivity.class.getSimpleName();
    private String first;
    private String second;
    private String operand;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState != null){
            TextView sc = findViewById(R.id.ShowCalc);
            String savedShow = savedInstanceState.getString("show");
            sc.setText(savedShow);
            first = savedInstanceState.getString("first");
            second = savedInstanceState.getString("second");
            operand = savedInstanceState.getString("operand");
        }else{
            first = "";
            second = "";
            operand = null;
        }
    }

    public void OperationalButton(View v){
        Button b = ((Button) v);
        TextView sc = findViewById(R.id.ShowCalc);
        String sc_content = sc.getText().toString();
        String b_text = b.getText().toString();
        if (b_text.equals("0") && (first.equals("0")||second.equals("0"))){
            // skip if multiple points occurs
            return;
        }
        // Check if another operator is pressed while two numbers and an operator are already set
        boolean operand_check = b_text.equals("+") || b_text.equals("-") || b_text.equals("*") || b_text.equals("/");
        if (!second.equals("") && operand_check) {
            // remember the pressed operator (operand = b_text; not necessary)
            EqualsButton(v);
            // while done the result re-obtain the operand to continue to concatenate operations
            operand = b_text;
        }else if (b_text.equals(".")) {
            if ((!first.contains(".") && operand == null) || (!second.contains(".") && operand != null)) {
                // add the point to the current number
                if (operand == null) {
                    if (first.equals("")) {
                        // insert "0." as default if first number is empty and the "." button is clicked
                        first = "0.";
                    } else {
                        first = first.concat(b_text);
                    }
                    sc.setText(first);
                } else {
                    if (second.equals("")) {
                        // insert "0." as default if second number is empty
                        second = "0.";
                    } else {
                        second = second.concat(b_text);
                    }
                    sc.setText(second);
                }
            } else {
                Toast.makeText(this, "inserting multiple decimal points", Toast.LENGTH_SHORT).show();
            }
            // save the first number when operators occurs
        } else if(operand_check){
            // we are in the case that no other operands are already set
            operand = b_text;
            first = sc_content;
            //sc.setText(""); check if necessary
            Log.d(LOG_TAG, "Added for the first time the Operand");
        }
        // since no operand are passed continue to set the first number
        else if (operand == null){
            // if we have touched 0 we need to remove it if other numbers occur
            if(first.equals("0")){
                first = "";
            }
            first = first.concat(b_text);
            sc.setText(first);
        }
        // otherwise obtain the second number
        else {
            if(second.equals("0")){ // same as before
                second = "";
            }
            second = second.concat(b_text);
            sc.setText(second);
        }
    }

    public void EqualsButton(View view){
        TextView sc = findViewById(R.id.ShowCalc);
        if (!second.equals("") && operand != null) {
            double num1 = Double.parseDouble(first);
            double num2 = Double.parseDouble(second);
            double res = 0;
            switch(operand){
                case "+":
                    res = num1 + num2;
                    break;
                case "-":
                    res = num1 - num2;
                    break;
                case "*":
                    res = num1 * num2;
                    break;
                case "/":
                    if (num2 == 0) {
                        Toast.makeText(this, "Can't divide by zero", Toast.LENGTH_SHORT).show();
                        second = "";
                        return;
                    }
                    res = num1 / num2;
                    break;
            }
            if (res == (int)res) { // check if result is an integer
                sc.setText(String.format("%d", (int)res)); // format as integer
                first = String.valueOf((int)res);
            } else {
                sc.setText(String.valueOf(res)); // otherwise, use original format
                first = String.valueOf(res);
            }
            second = "";
            operand = null;
        }
    }

    public void clear(View view){
        first = "";
        second = "";
        operand = null;
        TextView sc = findViewById(R.id.ShowCalc);
        sc.setText("0");
    }

    public void delete(View view){
        TextView sc = findViewById(R.id.ShowCalc);
        //String sc_content = sc.getText().toString();
        if(!second.equals("")){
            second = second.substring(0, second.length() - 1);
            sc.setText(second);
        }
        else if(!first.equals("")){
            first = first.substring(0, first.length() - 1);
            sc.setText(first);
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        TextView tv = findViewById(R.id.ShowCalc);
        // save info
        outState.putString("show", String.valueOf(tv.getText()));
        outState.putString("first", first);
        outState.putString("second", second);
        outState.putString("operand", operand);
    }
}