package com.first.sensorapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.hardware.Sensor;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    private SensorManager sensorManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // set the listeners for the buttons
        Button light = (Button) findViewById(R.id.LightSensor);
        final int intent_light = 1;
        light.setOnClickListener(v -> dispatchIntent(intent_light));
        Button chart = (Button) findViewById(R.id.Chart);
        final int intent_chart = 2;
        chart.setOnClickListener(v -> dispatchIntent(intent_chart));
        // get the sensorManager to find sensors
        sensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        List<Sensor> deviceSensors = sensorManager.getSensorList(Sensor.TYPE_ALL);
        // get the lenght of the list of sensors
        int lenght = deviceSensors.size();
        TextView number = (TextView) findViewById(R.id.NumberOfSensors);
        String numberOfSensors = "Number of Sensors = "+lenght;
        number.setText(numberOfSensors);
        // make visible the list of sensors
        TextView list = (TextView) findViewById(R.id.SensorsList);
        for(int i = 0; i < lenght; i++) list.append(deviceSensors.get(i).getName()+"\n");
    }

    public void dispatchIntent(int intent_number){
        if(intent_number == 1){
            Intent intent = new Intent(this, Light.class);
            startActivity(intent);
        } else if(intent_number == 2){
            Intent intent = new Intent(this, Chart.class);
            startActivity(intent);
        }
    }
}