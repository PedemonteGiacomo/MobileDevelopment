package com.first.simplecamera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;

public class MainActivity extends AppCompatActivity {
    // Class name for Log tag.
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    private SharedPreferences mPreferences;
    private File fileINT;
    private File fileEXT;
    private File fileSD;

    private String mPathINT;
    private String mPathEXT;
    private String mPathSD;

    private String sharedPathFile;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ImageView imgINT = findViewById(R.id.LIV);
        ImageView imgEXT = findViewById(R.id.LIV2);
        ImageView imgSD = findViewById(R.id.LIV3);

        //take the path saved into a sharedFile
        sharedPathFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPathFile, MODE_PRIVATE);
        mPathINT = mPreferences.getString("path", "");
        mPathEXT = mPreferences.getString("pathEXT", "");
        mPathSD = mPreferences.getString("pathSD", "");
        if(!mPathINT.equals("")){
            Log.d(LOG_TAG, mPathINT);
            fileINT = new File(mPathINT);
            loadImageFromStorage(fileINT,imgINT);
        }
        if(!mPathEXT.equals("")){
            Log.d(LOG_TAG, mPathEXT);
            fileEXT = new File(mPathEXT);
            loadImageFromStorage(fileEXT,imgEXT);
        }
        if(!mPathSD.equals("")) {
            Log.d(LOG_TAG, mPathSD);
            fileSD = new File(mPathSD);
            loadImageFromStorage(fileSD,imgSD);
        }
    }

    private void loadImageFromStorage(File file, ImageView img)
    {
        try {
            Bitmap b = BitmapFactory.decodeStream(new FileInputStream(file));
            Log.d(LOG_TAG,"bitmap decode succesfully");
            img.setImageBitmap(b);
        }
        catch (FileNotFoundException e) {e.printStackTrace();}
    }

    public void Picture(View v){
        Intent intent = new Intent(this, Picture.class);
        startActivity(intent);
    }

    public void CameraSettings(View v){
        Intent intent = new Intent(this, Settings1.class);
        startActivity(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
        ImageView imgINT = findViewById(R.id.LIV);
        ImageView imgEXT = findViewById(R.id.LIV2);
        ImageView imgSD = findViewById(R.id.LIV3);

        //take the path saved into a sharedFile
        sharedPathFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPathFile, MODE_PRIVATE);
        mPathINT = mPreferences.getString("path", "");
        mPathEXT = mPreferences.getString("pathEXT", "");
        mPathSD = mPreferences.getString("pathSD", "");
        if(!mPathINT.equals("")){
            Log.d(LOG_TAG, mPathINT);
            fileINT = new File(mPathINT);
            loadImageFromStorage(fileINT,imgINT);
        }
        if(!mPathEXT.equals("")){
            Log.d(LOG_TAG, mPathEXT);
            fileEXT = new File(mPathEXT);
            loadImageFromStorage(fileEXT,imgEXT);
        }
        if(!mPathSD.equals("")) {
            Log.d(LOG_TAG, mPathSD);
            fileSD = new File(mPathSD);
            loadImageFromStorage(fileSD,imgSD);
        }
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
        ImageView imgINT = findViewById(R.id.LIV);
        ImageView imgEXT = findViewById(R.id.LIV2);
        ImageView imgSD = findViewById(R.id.LIV3);

        //take the path saved into a sharedFile
        sharedPathFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPathFile, MODE_PRIVATE);
        mPathINT = mPreferences.getString("path", "");
        mPathEXT = mPreferences.getString("pathEXT", "");
        mPathSD = mPreferences.getString("pathSD", "");
        if(!mPathINT.equals("")){
            Log.d(LOG_TAG, mPathINT);
            fileINT = new File(mPathINT);
            loadImageFromStorage(fileINT,imgINT);
        }
        if(!mPathEXT.equals("")){
            Log.d(LOG_TAG, mPathEXT);
            fileEXT = new File(mPathEXT);
            loadImageFromStorage(fileEXT,imgEXT);
        }
        if(!mPathSD.equals("")) {
            Log.d(LOG_TAG, mPathSD);
            fileSD = new File(mPathSD);
            loadImageFromStorage(fileSD,imgSD);
        }
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(LOG_TAG, "onResume");
        ImageView imgINT = findViewById(R.id.LIV);
        ImageView imgEXT = findViewById(R.id.LIV2);
        ImageView imgSD = findViewById(R.id.LIV3);

        //take the path saved into a sharedFile
        sharedPathFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPathFile, MODE_PRIVATE);
        mPathINT = mPreferences.getString("path", "");
        mPathEXT = mPreferences.getString("pathEXT", "");
        mPathSD = mPreferences.getString("pathSD", "");
        if(!mPathINT.equals("")){
            Log.d(LOG_TAG, mPathINT);
            fileINT = new File(mPathINT);
            loadImageFromStorage(fileINT,imgINT);
        }
        if(!mPathEXT.equals("")){
            Log.d(LOG_TAG, mPathEXT);
            fileEXT = new File(mPathEXT);
            loadImageFromStorage(fileEXT,imgEXT);
        }
        if(!mPathSD.equals("")) {
            Log.d(LOG_TAG, mPathSD);
            fileSD = new File(mPathSD);
            loadImageFromStorage(fileSD,imgSD);
        }
    }

}