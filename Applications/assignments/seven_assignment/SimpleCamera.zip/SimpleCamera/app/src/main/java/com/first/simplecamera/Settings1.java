package com.first.simplecamera;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;

public class Settings1 extends AppCompatActivity {
    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    private File file;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings1);

        Button Test = findViewById(R.id.TEST);
        TextView TT = findViewById(R.id.TT);
        Test.setOnClickListener(v -> TT.setText(R.string.click));
        Test.setOnLongClickListener(v -> {
            TT.setText(R.string.long_click);
            return true;
        });

        Context context = getApplicationContext();
        File path = context.getFilesDir();
        file = new File(path, "cameratry.txt");
    }

    public void WriteFile(View v) {
        try (FileOutputStream stream = new FileOutputStream(file)) {
            TextView TTS = findViewById(R.id.TTS);
            stream.write(TTS.getText().toString().getBytes());
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    public void ReadFIle(View v) throws IOException {
        // read the file
        int length = (int) file.length();
        byte[] bytes = new byte[length];
        int byteRes;

        FileInputStream in = new FileInputStream(file);
        TextView TTBS = findViewById(R.id.TTBS);
        try {
            byteRes = in.read(bytes);
            if(byteRes == -1){
                Log.d(LOG_TAG, "No data to read");
            }
        } catch (IOException e) {
            throw new RuntimeException(e);
        } finally {
            in.close();
        }

        String contents = new String(bytes);
        TTBS.setText(contents);
    }

    public void ReturnBack(View v){
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        //finish();
    }

    public void GoToSettings2(View v){
        Intent intent = new Intent(this, Settings2.class);
        startActivity(intent);
        //finish();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }

}