package com.first.simplecamera;

import static android.util.Log.ERROR;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;
import android.Manifest;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class Picture extends AppCompatActivity {

    private static final String LOG_TAG = Picture.class.getSimpleName();
    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int CAMERA_PERMISSION_CODE = 2;
    private static final int WRITE_EXTERNAL_STORAGE_REQUEST_CODE = 3;
    private static final int MANAGE_EXTERNAL_STORAGE_REQUEST_CODE = 4;
    private ImageView mImageView;
    private ImageView mImageView2;
    private Bitmap mLastImage;
    private Bitmap mSecondLastImage;
    private SharedPreferences mPreferences;
    private String mImageViewDate;
    private String mImageView2Date;
    private String imageToSavePath;

    private String imageToSavePathEXT;

    private String imageToSavePathSD;

    ByteArrayOutputStream bytearrayoutputstream;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_picture);

        mImageView = findViewById(R.id.IV);
        mImageView2 = findViewById(R.id.IV2);

        Button takePictureButton = findViewById(R.id.PICTURE);
        takePictureButton.setOnClickListener(v -> dispatchTakePictureIntent());

        // make possible to delete a image when long clicking it
        mImageView.setOnLongClickListener(v -> {
            showDeleteConfirmationDialog(1);
            return true;
        });
        mImageView2.setOnLongClickListener(v -> {
            showDeleteConfirmationDialog(2);
            return true;
        });

        // get the date and time on which the photo was taken
        mImageView.setOnClickListener(v -> showDateTime(0));
        mImageView2.setOnClickListener(v -> showDateTime(1));

        //take the path saved into a sharedFile
        String sharedPathFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPathFile, MODE_PRIVATE);
    }

    //function to get the Date displayed
    private void showDateTime(int image){
        if(image == 0){
            Toast.makeText(this, "Image taken at " + mImageViewDate, Toast.LENGTH_LONG).show(); // Display the date and time in a Toast message
        } else if (image == 1) {
            Toast.makeText(this, "Image taken at " + mImageView2Date, Toast.LENGTH_LONG).show();
        } else{
            Toast.makeText(this, "Not valid id picture choice", Toast.LENGTH_SHORT).show();
        }
    }

    private void dispatchTakePictureIntent() {
        // Check if CAMERA permission is granted
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {
            // Request CAMERA permission if not granted
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.CAMERA},
                    CAMERA_PERMISSION_CODE);
        } else {
            // Start camera intent if permission is already granted
            Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CAMERA_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Start camera intent if permission is granted
                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                if (cameraIntent.resolveActivity(getPackageManager()) != null) {
                    startActivityForResult(cameraIntent, REQUEST_IMAGE_CAPTURE);
                }
            } else {
                // Show a message or take other action if permission is denied
                Toast.makeText(this, "Camera permission denied", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_IMAGE_CAPTURE && resultCode == RESULT_OK) {
            // Display captured image in the first ImageView
            assert data != null;
            Bundle extras = data.getExtras();
            Bitmap imageBitmap = (Bitmap) extras.get("data");

            // Save the last two images
            mSecondLastImage = mLastImage;
            mLastImage = imageBitmap;

            // Display the last two images in the ImageViews
            if (mLastImage != null) {
                mImageView.setImageBitmap(mLastImage);
            }
            if (mSecondLastImage != null) {
                mImageView2.setImageBitmap(mSecondLastImage);
            }

            // save also the date to simple get the data of the images
            String date =  new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());
            mImageView2Date = mImageViewDate;
            mImageViewDate = date;
        }
    }

    private void showDeleteConfirmationDialog(final int position) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage("Are you sure you want to delete this image?");
        builder.setPositiveButton("Delete", (dialog, which) -> {
            deleteImage(position);
            dialog.dismiss();
        });
        builder.setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss());
        builder.show();
    }

    private void deleteImage(int position) {
        if (position == 1) {
            mLastImage = mSecondLastImage;
            mSecondLastImage = null;
            mImageView.setImageBitmap(mLastImage);
            mImageView2.setImageBitmap(null);
        } else {
            mSecondLastImage = null;
            mImageView2.setImageBitmap(null);
        }
        Toast.makeText(this, "Image deleted", Toast.LENGTH_SHORT).show();
    }

    public void SaveLastPhoto(View view) {
        if (mLastImage != null) {
            // Save the bitmap to a file to get the date and time further
            if(getFreeInternalMemory()>0){
                Toast.makeText(this, "Ready", Toast.LENGTH_SHORT).show();
                saveToInternalStorage(mLastImage);
                Toast.makeText(this, "Remaining Storage " + formatSize(getFreeInternalMemory()) + " on " + formatSize(getTotalInternalMemorySize()), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Cannot save the Image", Toast.LENGTH_SHORT).show();
            }
            SharedPreferences.Editor preferencesEditor = mPreferences.edit();
            preferencesEditor.putString("path", imageToSavePath);
            preferencesEditor.apply();
            Toast.makeText(this, "Image saved (INT)", Toast.LENGTH_SHORT).show();
        }
    }

    static public String formatSize(long size) {
        String suffix = null;
        if (size >= 1024) {
            suffix = "KiB";
            size /= 1024;
            if (size >= 1024) {
                suffix = "MiB";
                size /= 1024;
            }
        }
        StringBuilder resultBuffer = new StringBuilder(Long.toString(size));
        int commaOffset = resultBuffer.length() - 3;
        while (commaOffset > 0) {
            resultBuffer.insert(commaOffset, ',');
            commaOffset -= 3;
        }
        if (suffix != null)
            resultBuffer.append(suffix);
        return resultBuffer.toString();
    }

    // Get internal (data partition) free space
    // This will match what's shown in System Settings > Storage for
    // Internal Space, when you subtract Total - Used
    public long getFreeInternalMemory() {
        return getFreeMemory(Environment.getDataDirectory());
    }

    static public long getTotalInternalMemorySize() {
        File path = Environment.getDataDirectory();
        StatFs stat = new StatFs(path.getPath());
        long blockSize = stat.getBlockSize();
        long totalBlocks = stat.getBlockCount();
        return totalBlocks * blockSize;
    }

    public long getFreeExternalMemory(File path) {
        return getFreeMemory(path);
    }

    static public boolean externalMemoryAvailable(File path) {
        if(path != null) return android.os.Environment.getExternalStorageState(path).equals(android.os.Environment.MEDIA_MOUNTED);
        return android.os.Environment.getExternalStorageState().equals(android.os.Environment.MEDIA_MOUNTED);
    }

    static public long getTotalExternalMemorySize(File path) {
        if(externalMemoryAvailable(path)) {
            StatFs stat = new StatFs(path.getPath());
            long blockSize = stat.getBlockSize();
            long totalBlocks = stat.getBlockCount();
            return totalBlocks * blockSize;
        } else {
            return ERROR;
        }
    }
    // Get free space for provided path
    // Note that this will throw IllegalArgumentException for invalid paths
    public long getFreeMemory(File path) {
        StatFs stats = new StatFs(path.getAbsolutePath());
        return stats.getAvailableBlocksLong() * stats.getBlockSizeLong();
    }


    private void saveToInternalStorage(Bitmap bitmapImage){
        ContextWrapper cw = new ContextWrapper(getApplicationContext());
        // path to /data/user/0/com.first.simplecameraapp/app_files
        File directory = cw.getDir("files", Context.MODE_PRIVATE);
        // create a filename for each image taken to get the correct date and time
        String fileName = "lastimage_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".png"; // Add current date and time to the file name
        File mypath = new File(directory, fileName);

        //Log.d(LOG_TAG, mypath.getAbsolutePath());

        FileOutputStream fos = null;
        try {
            fos = new FileOutputStream(mypath);
            // Use the compress method on the BitMap object to write image to the OutputStream
            bitmapImage.compress(Bitmap.CompressFormat.PNG, 100, fos);
            imageToSavePath = mypath.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            try {
                assert fos != null;
                fos.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        //return directory.getAbsolutePath();
    }

    /* Checks if external storage is available for read and write */
    public boolean isExternalStorageWritable(File path) {
        String state = Environment.getExternalStorageState(path);
        // if the returned state is equal to MEDIA_MOUNTED,
        // then you can read and write your files
        if (Environment.MEDIA_MOUNTED.equals(state)) {
            return true;
        }
        return false;
    }

    /* Checks if external storage is available to at least read */
    public boolean isExternalStorageReadable(File path) {
        String state = Environment.getExternalStorageState(path);
        if (Environment.MEDIA_MOUNTED.equals(state) || Environment.MEDIA_MOUNTED_READ_ONLY.equals(state)) {
            return true;
        }
        return false;
    }
    public void SaveLastPhotoEXT(View view) {
        if (mLastImage != null) {
            File[] externalStorageVolumes = ContextCompat.getExternalFilesDirs(getApplicationContext(), Environment.DIRECTORY_PICTURES);
            // probably a partition of the device internal memory as external storage
            File pathPrimaryExternalStorage = externalStorageVolumes[0];
            // Save the bitmap to a file to get the date and time further
            if (getFreeExternalMemory(pathPrimaryExternalStorage) > 0) {
                Toast.makeText(this, "READY: External Memory Available", Toast.LENGTH_SHORT).show();
                if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    // Versions below Android 10 (API level 29) require permission to write to external storage
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                        // Permission not granted, request it
                        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, WRITE_EXTERNAL_STORAGE_REQUEST_CODE);
                    } else {
                        // Permission already granted, save the photo
                        Toast.makeText(this, "Permission granted", Toast.LENGTH_SHORT).show();
                        saveToExternalStorage(mLastImage, pathPrimaryExternalStorage);
                    }
                } else {
                    // For Android 10+ (API level 29+), no permission is required for writing to external storage
                    saveToExternalStorage(mLastImage, pathPrimaryExternalStorage);
                }
                Toast.makeText(this, "Remaining Storage " + formatSize(getFreeExternalMemory(pathPrimaryExternalStorage)) + " on " + formatSize(getTotalExternalMemorySize(pathPrimaryExternalStorage)), Toast.LENGTH_LONG).show();
            } else {
                Toast.makeText(this, "Cannot save the Image", Toast.LENGTH_SHORT).show();
            }
            SharedPreferences.Editor preferencesEditor = mPreferences.edit();
            preferencesEditor.putString("pathEXT", imageToSavePathEXT);
            preferencesEditor.apply();
            Log.d(LOG_TAG, "pathEXT added " + imageToSavePathEXT);
            Toast.makeText(this, "Image saved (EXT)", Toast.LENGTH_SHORT).show();
        }
    }

    public void SaveLastPhotoSD(View view) {
        if (mLastImage != null) {
            File[] externalStorageVolumes = ContextCompat.getExternalFilesDirs(getApplicationContext(), Environment.DIRECTORY_PICTURES);
            File pathSDCard = null;
            File storageVolume = null;
            boolean found = false;
            if (externalStorageVolumes.length > 1) {
                //Toast.makeText(this, "Storage volumes available SD", Toast.LENGTH_LONG).show();
                for (int i = 1; i < externalStorageVolumes.length; i++) {
                    storageVolume = externalStorageVolumes[i];
                    if (storageVolume != null && !Environment.isExternalStorageEmulated(storageVolume)) {
                        pathSDCard = storageVolume;
                        Log.d(LOG_TAG, "External SD card storage found at index: " + i);
                        found = true;
                        break;
                    }
                }
                if(found){
                    // Save the bitmap to a file to get the date and time further
                    if (getFreeExternalMemory(pathSDCard) > 0) {
                        saveToExternalStorage(mLastImage, storageVolume);
                        Toast.makeText(this, "Remaining Storage " + formatSize(getFreeExternalMemory(pathSDCard)) + " on " + formatSize(getTotalExternalMemorySize(pathSDCard)), Toast.LENGTH_LONG).show();
                    } else {
                        Toast.makeText(this, "No more space left on SD", Toast.LENGTH_SHORT).show();
                    }
                    SharedPreferences.Editor preferencesEditor = mPreferences.edit();
                    preferencesEditor.putString("pathSD", imageToSavePathEXT);
                    preferencesEditor.apply();
                    //if(imageToSavePathSD != null) Log.d(LOG_TAG, "pathSD succesfully applied to preferences");
                    Toast.makeText(this, "Image saved (SD)", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(this, "Cannot access to SD", Toast.LENGTH_SHORT).show();
                }
            }else{
                Toast.makeText(this, "Cannot find SD", Toast.LENGTH_SHORT).show();
            }

        }
    }

    public void saveToExternalStorage(Bitmap image, File path) {
        String fem, tem;
        bytearrayoutputstream = new ByteArrayOutputStream();
        // maybe in the following we just need to check if it is writable and when we need to retrieve the image(in the main activity) I will need to use isExternalStorageReadable()
        if(isExternalStorageReadable(path) && isExternalStorageWritable(path)){
                Toast.makeText(this, "Ready", Toast.LENGTH_LONG).show();
                //Bitmap bitmap = image;
                String fileName = "lastimage_" + new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date()) + ".png";
                image.compress(Bitmap.CompressFormat.PNG, 60, bytearrayoutputstream);
                File file = new File(path, fileName);
                try{
                    if(file.createNewFile()) Log.d(LOG_TAG, "created");
                    else Log.d(LOG_TAG, "already created");
                    FileOutputStream fileoutputstream = new FileOutputStream(file);
                    fileoutputstream.write(bytearrayoutputstream.toByteArray());
                    fileoutputstream.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
                imageToSavePathEXT = file.getAbsolutePath();
                //Log.d(LOG_TAG, "END "+imageToSavePathEXT);
        }else {
            Log.d(LOG_TAG, "Cannot access to ExternalStorage");
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
        // get the date and time on which the photo was taken
        mImageView.setOnClickListener(v -> showDateTime(0));
        mImageView2.setOnClickListener(v -> showDateTime(1));
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }

}