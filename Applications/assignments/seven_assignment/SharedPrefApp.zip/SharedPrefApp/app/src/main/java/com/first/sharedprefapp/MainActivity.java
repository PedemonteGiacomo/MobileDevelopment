package com.first.sharedprefapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.Switch;

public class MainActivity extends AppCompatActivity {

    private SharedPreferences mPreferences;

    private String mUsername;

    private String mLocation;

    private static final String LOG_TAG = MainActivity.class.getSimpleName();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        String sharedPrefFile = "com.example.simplesavingsapp";
        mPreferences = getSharedPreferences(sharedPrefFile, MODE_PRIVATE);
        mUsername = mPreferences.getString("username", "");
        mLocation = mPreferences.getString("location", "");
        int mBackground = mPreferences.getInt("bg", 0);
        // use that values e.g., for initializing UI widgets
        EditText mUsernameView = findViewById(R.id.Username);
        EditText mLocationView = findViewById(R.id.Location);
        Switch sw = findViewById(R.id.BG);
        mUsernameView.setText(mUsername);
        mLocationView.setText(mLocation);
        if(mBackground == 1){
            sw.setChecked(true);
            getWindow().getDecorView().setBackgroundColor(Color.GRAY);
        }else{
            sw.setChecked(false);
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        }
        sw.setOnClickListener(view -> {
            if(sw.isChecked())
                getWindow().getDecorView().setBackgroundColor(Color.GRAY);
            else
                getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        });
    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.d(LOG_TAG, "onStart");
    }

    @Override
    protected void onRestart() {
        super.onRestart();
        Log.d(LOG_TAG, "onRestart");
    }

    @Override
    protected void onPause(){
        super.onPause();
        Log.d(LOG_TAG, "onPause");
    }

    @Override
    protected void onStop(){
        super.onStop();
        Log.d(LOG_TAG, "onStop");
    }

    @Override
    protected void onResume(){
        super.onResume();
        Log.d(LOG_TAG, "onResume");
    }

    public void Save(View v){
        EditText mUsernameView = findViewById(R.id.Username);
        EditText mLocationView = findViewById(R.id.Location);
        mUsername = mUsernameView.getText().toString();
        mLocation = mLocationView.getText().toString();
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        preferencesEditor.putString("username", mUsername);
        preferencesEditor.putString("location", mLocation);
        // get the background
        Switch sw = findViewById(R.id.BG);
        if(sw.isChecked())
            preferencesEditor.putInt("bg",1);
        else
            preferencesEditor.putInt("bg",0);
        preferencesEditor.apply();
    }

    public void Clear(View v){
        EditText mUsernameView = findViewById(R.id.Username);
        EditText mLocationView = findViewById(R.id.Location);
        Switch sw = findViewById(R.id.BG);
        SharedPreferences.Editor preferencesEditor = mPreferences.edit();
        mUsername = "";
        mLocation = "";
        mUsernameView.setText(mUsername);
        mLocationView.setText(mLocation);
        sw.setChecked(false);
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        preferencesEditor.clear();
        preferencesEditor.apply();
    }

    public void Finish(View v){finish();}
    @Override
    public void finish() {
        if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
            super.finishAndRemoveTask();
        else
            super.finish();
    }
}