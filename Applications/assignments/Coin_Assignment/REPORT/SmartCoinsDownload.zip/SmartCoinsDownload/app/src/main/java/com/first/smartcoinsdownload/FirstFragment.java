package com.first.smartcoinsdownload;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

import com.first.smartcoinsdownload.databinding.FragmentFirstBinding;

import java.io.InputStream;

public class FirstFragment extends Fragment {

    private FragmentFirstBinding binding;

    String url1 = "https://upload.wikimedia.org/wikipedia/commons/0/0a/George_Washington_Presidential_%241_Coin_obverse.png";
    String url2 = "https://upload.wikimedia.org/wikipedia/commons/f/f0/1976S_Type1_Eisenhower_Reverse.jpg";
    String url3 = "https://upload.wikimedia.org/wikipedia/commons/d/d7/2009NativeAmericanRev.jpg";
    String url4 = "https://upload.wikimedia.org/wikipedia/commons/1/1a/2006_AESilver_Proof_Obv.png";
    String url5 = "https://upload.wikimedia.org/wikipedia/commons/c/c6/1879S_Morgan_Dollar_NGC_MS67plus_Obverse.png";
    String url6 = "https://upload.wikimedia.org/wikipedia/commons/b/b9/1974S_Eisenhower_Obverse.jpg";
    String url7 = "https://upload.wikimedia.org/wikipedia/commons/5/54/2003_Sacagawea_Rev.png";
    String url8 = "https://upload.wikimedia.org/wikipedia/en/f/fe/Sacagawea_dollar_obverse.png";
    String url9 = "https://upload.wikimedia.org/wikipedia/commons/f/fa/Presidential_dollar_coin_reverse.png";
    String[] urls;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = FragmentFirstBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        // Get the URLs from the arguments
        urls = new String[]{url1, url2, url3, url4, url5, url6, url7, url8, url9};
        // Set click listeners for the ImageViews
        ImageView[] imageViews = {
                binding.imageView11, binding.imageView12, binding.imageView13,
                binding.imageView21, binding.imageView22, binding.ImageView23,
                binding.imageView31, binding.imageView32, binding.imageView33
        };
        for (int i = 0; i < imageViews.length; i++) {
            final int index = i;
            imageViews[i].setOnClickListener(v -> new FirstFragment.DownloadImageTask(imageViews[index]).execute(urls[index]));
        }
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected void onPreExecute() {
            // Display "Download started" Toast
            Context context = getActivity();
            Toast.makeText(context, "Download started", Toast.LENGTH_SHORT).show();
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon;
        }
        protected void onPostExecute(Bitmap result) {
            // Get the fragment context
            Context context = getActivity();
            if (context != null) {
                Toast.makeText(context, "Download finished", Toast.LENGTH_SHORT).show();
            }
            // Rotate the ImageView by 40 degrees for 87 times
            for (int i = 0; i < 87; i++) {
                bmImage.setRotation(bmImage.getRotation() + 20);
            }
            if (context != null) {
                Toast.makeText(context, "Rotation finished", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}