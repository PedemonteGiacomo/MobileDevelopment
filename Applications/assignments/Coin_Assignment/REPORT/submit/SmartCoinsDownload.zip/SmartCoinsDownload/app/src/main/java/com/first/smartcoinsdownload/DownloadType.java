package com.first.smartcoinsdownload;

import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.first.smartcoinsdownload.databinding.ActivityDownloadTypeBinding;

public class DownloadType extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityDownloadTypeBinding binding;

    NavController navController;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDownloadTypeBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        setSupportActionBar(binding.toolbar);
        navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_download_type);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_download_type);
        switch (item.getItemId()) {
            case R.id.action_first_fragment:
                navController.navigate(R.id.FirstFragment); //, FirstFragment.newInstance(urls)
                return true;
            case R.id.action_second_fragment:
                navController.navigate(R.id.SecondFragment);
                return true;
            case R.id.action_reset_fragment:
                Toast.makeText(this,"Reset clicked", Toast.LENGTH_SHORT).show();
                reset();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

    public void reset(){
        //first row images
        ImageView imageView1_1 = findViewById(R.id.imageView1_1);
        ImageView imageView1_2 = findViewById(R.id.imageView1_2);
        ImageView imageView1_3 = findViewById(R.id.imageView1_3);
        imageView1_1.setRotation(0);
        imageView1_2.setRotation(0);
        imageView1_3.setRotation(0);

        //second row images
        ImageView imageView2_1 = findViewById(R.id.imageView2_1);
        ImageView imageView2_2 = findViewById(R.id.imageView2_2);
        ImageView imageView2_3 = findViewById(R.id.ImageView2_3);
        imageView2_1.setRotation(0);
        imageView2_2.setRotation(0);
        imageView2_3.setRotation(0);

        //third row images
        ImageView imageView3_1 = findViewById(R.id.imageView3_1);
        ImageView imageView3_2 = findViewById(R.id.imageView3_2);
        ImageView imageView3_3 = findViewById(R.id.imageView3_3);
        imageView3_1.setRotation(0);
        imageView3_2.setRotation(0);
        imageView3_3.setRotation(0);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_download_type);
        return NavigationUI.navigateUp(navController, appBarConfiguration) || super.onSupportNavigateUp();
    }
}